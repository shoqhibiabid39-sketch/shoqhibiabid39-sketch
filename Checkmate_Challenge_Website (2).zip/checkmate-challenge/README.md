# Checkmate Challenge

Website game catur responsif untuk dimainkan melawan komputer.

## Jalankan
Buka `index.html` di browser dengan koneksi internet. Halaman memuat `chess.js` dari CDN untuk memvalidasi aturan dan langkah legal.

## Fitur
- Papan interaktif dengan koordinat A-H dan 1-8
- Main sebagai Putih atau Hitam
- Tingkat Pemula, Menengah, dan Mahir
- Catatan langkah, urungkan langkah, balik papan, petunjuk, dan salin PGN
- Tampilan responsif untuk desktop dan ponsel

## Publikasikan gratis dengan GitHub Pages
1. Buat akun / masuk ke GitHub.
2. Buat repository baru, misalnya `checkmate-challenge`.
3. Unggah `index.html` ke bagian root repository. `README.md` juga boleh diunggah.
4. Buka **Settings → Pages** pada repository.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu tekan **Save**.
7. Tunggu beberapa menit. GitHub Pages akan menampilkan alamat publik di bagian Pages, biasanya berbentuk `https://USERNAME.github.io/checkmate-challenge/`.
8. Buka alamat itu untuk menguji, lalu bagikan link tersebut.

Catatan: alamat publik dibuat oleh GitHub setelah Pages diaktifkan; jangan menebak link sebelum GitHub menampilkannya. Nama menu dapat sedikit berubah. Website menggunakan CDN `cdnjs.cloudflare.com`, jadi pemain perlu koneksi internet. AI adalah lawan komputer sederhana, bukan engine profesional.
